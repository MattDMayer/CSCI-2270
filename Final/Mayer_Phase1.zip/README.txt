miniGit is a lightweight git system to store sequential states of the files stored
It has functionality to save changed between versions of .cpp, .hpp, and .txt files
Running the driver starts a loop that you run in a different terminal than what you're editing
Through this terminal you can ask the miniGit object to save the states of specific files
You can also return to and checkout previous states of the commited files


Made with love by Lyra Sturdivant

Made with hate by Skyla Gyimesi

Made with sad by Matthew Mayer